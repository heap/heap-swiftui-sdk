import Heap
import Heap_SwiftUI

public struct ReleaseTester {
    public init() {
        let options = HeapOptions()
        options.debug = true
        Heap.initializeForSwiftUI("11", with: options)
    }
}

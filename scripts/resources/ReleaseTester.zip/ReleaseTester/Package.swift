// swift-tools-version:5.5

import PackageDescription

let package = Package(
    name: "ReleaseTester",
    platforms: [.iOS(.v14)],
    products: [
        .library(
            name: "ReleaseTester",
            targets: ["ReleaseTester"]),
    ],
    dependencies: [
        .package(path: "PATH_TO_HEAP_SWIFTUI"),
        .package(url: "https://github.com/heap/heap-ios-sdk.git", from: "9.0.0-alpha.1"),
    ],
    targets: [
        .target(
            name: "ReleaseTester",
            dependencies: [
                .product(name: "Heap_SwiftUI", package: "heap-swiftui-sdk"),
                .product(name: "Heap", package: "heap-ios-sdk"),
            ]),
    ]
)
